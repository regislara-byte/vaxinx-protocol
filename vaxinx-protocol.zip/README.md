# 🧬 VAXINX PROTOCOL DEFENSE DECK

A post-cyberpunk defense prototype built in raw HTML/CSS/JS — no frameworks, no shortcuts.  
Just pure code, neon lore, and digital warfare.

## 🔮 Theme

Set in the year 2050, **VAXINX** is the last line of defense against viral-chain entities spawned from corrupted protocols.  
Each card represents a rogue agent from the dark side of DeFi — powered by lore, backed by design, and ready to flip.

> *"The chain is broken, but the code remembers."*

## 🛠️ Built With

- HTML5 + CSS3 + Vanilla JS
- Designed in Notepad & VS Code
- No libraries, no builds — 100% handcrafted

## ⚙️ Features

- 🔥 Animated card flip effects (front/back views)
- 🧬 Deep lore for each card (origin, abilities, weaknesses)
- 🛡️ Custom security layer: anti-inspect, devtools alerts, fake breach protocol
- 🎮 Click-to-flip interactivity
- 🧠 Anti-copy & selection protection
- ☣️ Dark neon theme with cyber-glitch styling

## 🚀 Launch Locally

Clone this repo or download as ZIP.  
Make sure all assets (like `BGVaxinX.jpg` and card images) are in the same directory as `index.html`.

Then just open `index.html` in your browser.

```bash
git clone https://github.com/YOUR_USERNAME/vaxinx-protocol.git
```

> Or view the live site here:  
> 🌐 [https://YOUR_USERNAME.github.io/vaxinx-protocol](https://YOUR_USERNAME.github.io/vaxinx-protocol)

## 🎯 Phase 1 Complete

This deck is the first stage in a larger interactive cyber-defense project.  
Next phases may include:
- Game logic (HP, battles, rounds)
- Sound effects + ambient music
- Local or online PvP mode
- NFT-like card tracking (non-monetized, lore only)
- Leaderboards / Missions / Worldmap

## 🧙‍♂️ Credits

> **Code, Design, Lore**: Handcrafted by [Your Name / Alias]  
> 🤖 Assistant: ChatGPT (OpenAI)  
> ⚔️ Creative Warpath: You

---

© 2025 | Ronin Dojo x Urlifenuggets | VAXINX Satellite Division  
**Chaos Mode: PROTECTED.**
